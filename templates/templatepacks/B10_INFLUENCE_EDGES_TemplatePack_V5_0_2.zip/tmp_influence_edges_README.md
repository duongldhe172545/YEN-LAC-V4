# TMP_INFLUENCE_EDGES (V5.0.2)

- File CSV mẫu: `tmp_influence_edges.csv`
- Schema: `tmp_influence_edges.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
