# TMP_INCIDENT_RUMOR_LOG (V5.0.2)

- File CSV mẫu: `tmp_incident_rumor_log.csv`
- Schema: `tmp_incident_rumor_log.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
