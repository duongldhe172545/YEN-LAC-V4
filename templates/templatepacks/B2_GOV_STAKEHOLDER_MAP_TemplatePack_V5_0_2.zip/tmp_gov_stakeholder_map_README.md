# TMP_GOV_STAKEHOLDER_MAP (V5.0.2)

- File CSV mẫu: `tmp_gov_stakeholder_map.csv`
- Schema: `tmp_gov_stakeholder_map.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
