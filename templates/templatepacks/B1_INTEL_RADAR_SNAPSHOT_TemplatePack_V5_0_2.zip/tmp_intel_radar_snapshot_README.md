# TMP_INTEL_RADAR_SNAPSHOT (V5.0.2)

- File CSV mẫu: `tmp_intel_radar_snapshot.csv`
- Schema: `tmp_intel_radar_snapshot.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
