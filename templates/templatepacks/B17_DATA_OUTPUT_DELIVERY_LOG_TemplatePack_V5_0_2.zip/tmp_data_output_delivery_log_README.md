# TMP_DATA_OUTPUT_DELIVERY_LOG (V5.0.2)

- File CSV mẫu: `tmp_data_output_delivery_log.csv`
- Schema: `tmp_data_output_delivery_log.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
