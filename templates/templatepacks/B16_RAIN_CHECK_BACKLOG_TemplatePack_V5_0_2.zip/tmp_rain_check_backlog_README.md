# TMP_RAIN_CHECK_BACKLOG (V5.0.2)

- File CSV mẫu: `tmp_rain_check_backlog.csv`
- Schema: `tmp_rain_check_backlog.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
