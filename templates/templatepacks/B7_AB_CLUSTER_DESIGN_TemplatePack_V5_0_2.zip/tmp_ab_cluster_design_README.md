# TMP_AB_CLUSTER_DESIGN (V5.0.2)

- File CSV mẫu: `tmp_ab_cluster_design.csv`
- Schema: `tmp_ab_cluster_design.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
