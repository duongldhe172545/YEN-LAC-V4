# A2 ACTOR_MASTER (V5.0.2)

Mục đích: tạo danh bạ tác nhân chuẩn để mọi sự kiện (EVT_*) và nghiệp vụ (gate/payout/ops) tham chiếu bằng `actor_id`.

- Append-only (chỉ thêm): không overwrite record cũ. Sai thì dùng quarantine/correction event.
- Non-PII: không ghi tên thật/số điện thoại/CCCD vào file này.
- `pii_ref` chỉ là mã tham chiếu sang PII Vault (khi đã có consent).

## File trong pack
- `A2_actor_master.csv`: mẫu CSV + 1 dòng ví dụ
- `A2_actor_master.schema.yaml`: schema + enum + ingest policy + validate rules

## Lưu ý ingest
Cột `ops_raci_hint`, `ops_cost_hint_vnd` là ops_only. Khi ingest canonical phải drop.
