# TMP_GOV_DELIVERABLES_TRACKER (V5.0.2)

- File CSV mẫu: `tmp_gov_deliverables_tracker.csv`
- Schema: `tmp_gov_deliverables_tracker.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
