# A7 – EVENTS EVT_* (V5.0.2)

## Dùng để làm gì?
Đây là **nhật ký sự kiện (event log = sổ cái sự kiện)**, append-only (chỉ thêm) cho toàn hệ thống.
Máy sẽ:
- Validate theo `registry/events.yaml` (registry-first = sổ chuẩn trước).
- Dedupe (chống trùng) theo `idempotency_key`.
- Quarantine (cách ly) bản ghi lỗi, không làm gãy luồng.

## Cột bắt buộc
- `event_code` (EVT_*)
- `event_ts` (ISO 8601)
- `actor_id` (mã nội bộ)
- `idempotency_key` (khóa chống ghi trùng)

## payload_json
`payload_json` là chỗ để nhét field chi tiết theo từng event (ví dụ roof_area_m2, imagery_uri, cash_collected_vnd...).
**Không được nhét PII** (SĐT/CCCD/tên thật) vào payload.

## Golden Path (12 event) để chạy GĐ1
Xem sheet `_HELP` trong Excel.
