# A1 HOUSE_MASTER (V5.0.2)

## Dành cho người chạy cơm
- Mở file Excel: **A1_HOUSE_MASTER_V5_0_2.xlsx**
- Điền dữ liệu tại sheet **HOUSE_MASTER** (từ dòng 2 trở xuống).
- Không nhập PII (tên/sđt/CCCD). PII phải đi qua Consent và lưu ở PII Vault.

### Quy ước màu
- ĐỎ: Bắt buộc (thiếu là quarantine)
- XANH: Khuyến nghị
- VÀNG: provider_raw (thô)
- XÁM: ops_only (chỉ chạy cơm, không ingest)

## Dành cho máy đọc
- CSV mẫu: **A1_house_master.csv**
- Schema YAML: **A1_house_master.schema.yaml**

## Keys
- primary: house_id
- join: geo_unit_code, source_batch_id
