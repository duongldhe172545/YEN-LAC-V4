# A6 – PREFLIGHT_BATCH_CHECK (V5.0.2)

## Dùng để làm gì?
**Preflight** (kiểm tra trước khi nạp) là bước “soi lỗi” (linter) để:
- Chặn lỗi trước khi ingest (nạp vào máy) – *fail fast* (fail sớm).
- Ghi audit log cho quyết định: **INGEST / QUARANTINE / REJECT**.
- Bảo vệ nguyên tắc **append-only** (chỉ thêm, không sửa lịch sử) và **registry-first** (sổ chuẩn trước).

## Khi nào dùng?
Trước khi nạp bất kỳ batch Excel/CSV nào vào hệ thống.

## Cột quan trọng nhất
- `batch_id`: khóa chính của lô.
- `preflight_result`: PASS/FAIL.
- `quarantine_action`: INGEST/QUARANTINE/REJECT.
- `checksum_manifest`: hash để đối soát file.
- `fail_reason_codes`: mã lỗi (phân cách bằng ';').

## Lưu ý PII
Không được nhét số điện thoại/CCCD/tên người thật vào template này.
`producer_actor_id` chỉ là **mã nội bộ** (pseudonymous id).

## Ví dụ 1 dòng
Xem file CSV mẫu đi kèm.
