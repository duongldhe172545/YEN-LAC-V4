# TMP_SEASONALITY_CALENDAR (V5.0.2)

- File CSV mẫu: `tmp_seasonality_calendar.csv`
- Schema: `tmp_seasonality_calendar.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
