# TMP_ENTERPRISE_CENSUS (V5.0.2)

- File CSV mẫu: `tmp_enterprise_census.csv`
- Schema: `tmp_enterprise_census.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
