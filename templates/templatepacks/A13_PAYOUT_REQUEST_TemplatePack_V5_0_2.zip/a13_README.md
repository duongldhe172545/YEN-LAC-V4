# A13 (V5.0.2)

Xem sheet `_HELP` trong Excel để hiểu cột và luật kiểm.
