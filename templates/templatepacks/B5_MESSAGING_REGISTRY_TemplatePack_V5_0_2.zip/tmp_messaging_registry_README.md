# TMP_MESSAGING_REGISTRY (V5.0.2)

- File CSV mẫu: `tmp_messaging_registry.csv`
- Schema: `tmp_messaging_registry.schema.yaml`

Đây là template dữ liệu mềm (soft intel). Một số trường là proxy/score nên cần người review.
